#include <windows.h>
#include <stdio.h>

extern HWND LogBoxHandle;
void Log(const char* format,...);
