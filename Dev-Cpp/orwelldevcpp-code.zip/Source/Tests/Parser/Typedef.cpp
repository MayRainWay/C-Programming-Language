/*
	Complicated typedef
*/
typedef struct tagREKT {
  LONG left;
  LONG top;
  LONG right;
  LONG bottom;
} REKT,*PREKT,*NPREKT,*LPREKT;
